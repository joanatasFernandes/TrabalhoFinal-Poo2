package com.company.controller;

import com.company.view.MainView;

public class MainController {

	private MainView mainView;

	public MainController() {
		this.mainView = new MainView("Notas Alunos");
	}
}
