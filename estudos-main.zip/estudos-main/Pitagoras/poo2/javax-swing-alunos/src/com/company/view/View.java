package com.company.view;

import javax.swing.JPanel;

public interface View {

	JPanel getView();
}
