package com.company;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		LabelFrame labelFrame = new LabelFrame();
		labelFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		labelFrame.setSize(380, 380);
		labelFrame.setVisible(true);
	}
}
