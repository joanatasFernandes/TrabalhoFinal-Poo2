package com.example.trabalhofinal.controller.delegate;

import javafx.scene.control.Tab;

public interface TabMenuDelegate {
	void trocarConteudo(Tab tabContent);
}
