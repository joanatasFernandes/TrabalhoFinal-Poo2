CREATE TABLE alunos
(
    id   SERIAL PRIMARY KEY,
    nome VARCHAR,
    cpf  VARCHAR,
    rg   VARCHAR
);
