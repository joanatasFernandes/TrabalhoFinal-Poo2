package titular

type Titular struct {
	Nome      string
	CPF       string
	Profissao string
}
